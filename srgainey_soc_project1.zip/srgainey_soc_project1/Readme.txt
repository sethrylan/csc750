Unit and Functional Tests located in /tests folder:
	edu.ncsu.soc.srgainey.test.FriendMapperTest
	edu.ncsu.soc.srgainey.test.FriendViewAdapterTest
