/** Automatically generated file. DO NOT MODIFY */
package edu.ncsu.soc.project1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}